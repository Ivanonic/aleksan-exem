fun = (a) => {
    return a;
}